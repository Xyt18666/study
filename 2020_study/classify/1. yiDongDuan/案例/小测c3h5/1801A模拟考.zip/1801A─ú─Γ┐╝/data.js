[
	{
		"id":1,
		"name":"西红柿",
		"info":"小时候的味道",
		"weight":"约500g",
		"img":"images/1.png",
		"price":10.9
	},
	{
		"id":2,
		"name":"黄瓜 水果的味道",
		"info":"有机种植 健康饮食",
		"weight":"约500g",
		"img":"/images/2.png",
		"price":10.8
	},
	{
		"id":3,
		"name":"杂粮散养土鸡蛋",
		"info":"林下散养 只食五谷虫草",
		"weight":"10枚装/盒",
		"img":"/images/3.png",
		"price":19.9
	},
	{
		"id":4,
		"name":"小白菜",
		"info":"自然成熟 品味小时候味道",
		"weight":"约300g",
		"img":"/images/4.png",
		"price":8.8
	},
	{
		"id":5,
		"name":"长紫茄子",
		"info":"有机方式种植",
		"weight":"约500g",
		"img":"/images/5.png",
		"price":10.8
	},
	{
		"id":6,
		"name":"胡萝卜",
		"info":"自然生长富含营养",
		"weight":"约500g",
		"img":"/images/6.png",
		"price":10.8
	},
	{
		"id":7,
		"name":"土豆",
		"info":"有机方式种植 土壤肥沃",
		"weight":"约1000g",
		"img":"/images/7.png",
		"price":10.8
	},
	{
		"id":8,
		"name":"尖椒",
		"info":"健康种植 自然生长",
		"weight":"约500g",
		"img":"/images/8.png",
		"price":10.8
	},
	{
		"id":9,
		"name":"黑贵族五花肉",
		"info":"410天慢生长 无激素",
		"weight":"500g/袋",
		"img":"/images/9.png",
		"price":49.6
	},
	{
		"id":10,
		"name":"草原精选羊肉块",
		"info":"天然牧场 口味正宗",
		"weight":"750g",
		"img":"/images/10.png",
		"price":59.9
	},
]
